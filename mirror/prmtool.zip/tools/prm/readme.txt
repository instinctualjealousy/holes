PRM Tool v0.02
Further details can be found here: http://z3.invisionfree.com/Revolt_Live/index.php?showtopic=1397