=============NEED FOR SPEED6: HOT PURSUIT2 EDITED STUFF=============
Title                   : VIV Editor
Type			: Program
Used Editor(s)		: Cygnus Hex Editor, Visual Studio 6

Author                  : Addict
E-mail Address          : addictarts@pandora.be
Homepage		: http://addictarts.nfscheats.com/

Description             : This program allows you to edit VIV files
			  which are found in NFS3/4/6.

Installation		: Extract and run VIVEdit.exe.

Additional Credits to   : EA
====================================================================

NOTES
-----

Interface:
- New       : Creates a new VIV file (c:\unnamed.viv)
- Open      : Opens an existing VIV file
- Save      : Save VIV file to current location
- Save As   : Save VIV file to an alternative location
- Import    : Import a file into the VIV file
- Export    : Export all selected files
- Rename    : Rename first selected file
- Remove    : Remove all selected files
- Exit      : Close program
- Move Up   : Move first selected file up in the list
- Move Down : Move first selected file down in the list

Opening VIV files on startup:
This program supports Windows linking:
1) Double-click on a VIV file so the 'Open With' Dialog opens.
2) Click on 'Other...' and browse to VIVEdit.exe.
3) Select the option 'Always use this program to open this file'.
4) Click on 'OK'.
5) VIV files will now automatically open with VIVEdit.

Alternatively you can drag and drop a VIV file on VIVEdit.exe or
just use the 'Open' button in the interface.
