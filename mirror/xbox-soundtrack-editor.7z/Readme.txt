--------------------------------------------------------------------------------------------------
                               XBOX Soundtrack Editor v0.97
--------------------------------------------------------------------------------------------------



About XBOX Soundtrack Editor
--------------------------------------------------------------------------------------------------
Now you can edit XBOX Soundtrack from your PC.
Add/Remove/Rename soundtrack and music track with this program.
If you want to listen to the MP3s in the XBOX, change the MP3 to WMA format using converting
program like 'Advanced WMA Workshop'. (I recommend converting option Bitrate:128kbps,
Samplerate:44100Hz, Channel:Stereo) 
Then add the converted WMA to your XBOX using 'Add Track' menu in this program.
Enjoy 'Project Gotham Racing' changing the background music. :)



Installation
--------------------------------------------------------------------------------------------------
Run xboxst.exe in any folder.




Version History
--------------------------------------------------------------------------------------------------
v0.97
# WMA playback time recognition problem is still present.
- Added FTP username/password for evolutionX 1.8.2594
- Fixed bug when tracks were added same track appeared twice.
- Fixed bug that XBOX Soundtrack Editor CFG file was created at a wrong position.
- Fixed bug that XBOX Soundtrack Editor temporary file was not deleted.

v0.96
- Less Connection timeout time
- Some bug fixed on FTP
- Fixed bug when connection delayed 'Wait' icon disappeared.


v0.95
- First released version




Contact
--------------------------------------------------------------------------------------------------
E-Mail : cooltaxi@yahoo.co.kr
My favorite XBOX Website : http://www.xboxzone.co.kr
Nick Name : Redjoon
